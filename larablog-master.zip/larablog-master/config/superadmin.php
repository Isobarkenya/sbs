<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Inital Super User to be seeded
    |--------------------------------------------------------------------------
    */

    'baseSuperAdminUser01Name'     => env('INITIAL_SEEDED_SUPER_ADMIN_USERNAME', 'admin'),
    'baseSuperAdminUser01Email'    => env('INITIAL_SEEDED_SUPER_ADMIN_USEREMAIL', 'admin@admin.com'),
    'baseSuperAdminUser01PW'       => env('INITIAL_SEEDED_SUPER_ADMIN_USERPASSWORD', 'password'),
];
